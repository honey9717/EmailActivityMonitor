export class Email 
{
  body?: string = ''
  to?: string[]
  cc?: string[]
  sendAt?: Date = new Date()
  bcc?: string[]
  subject?: string
  createdAt?: Date = new Date()
  attachmentFileName?: string = ''
  emailStatus?: string = ''
  file?:any;
}
