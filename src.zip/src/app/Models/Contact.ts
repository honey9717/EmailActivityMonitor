export class Contacts
{
  address?: string
  lastName?: string
  firstName?: string
  phoneNumber?: number
  emailAddress?: string
  contactId?: number
}
