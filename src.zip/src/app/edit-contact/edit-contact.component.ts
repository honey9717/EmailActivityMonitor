import { Component, OnInit } from '@angular/core'
import { FormControl, FormGroup } from '@angular/forms'
import { Contacts } from '../Models/Contact'
import { ContactService } from '../Service/Contact,Service'
import { ToastrService } from 'ngx-toastr'
import { ActivatedRoute, Router } from '@angular/router'


@Component({
  selector: 'app-edit-contact',
  templateUrl: './edit-contact.component.html',
  styleUrls: ['./edit-contact.component.css'],
})
export class EditContactComponent implements OnInit {
  editContact: FormGroup
  contact: Contacts = new Contacts()
  contactId:number=0;

  constructor(
    private contactService: ContactService,
    private toastr: ToastrService,
    private Route:ActivatedRoute,
    private myRouter:Router
  ) {
    this.editContact = new FormGroup({
      contactId: new FormControl(''),
      address: new FormControl(''),
      lastName: new FormControl(''),
      firstName: new FormControl(''),
      phoneNumber: new FormControl(''),
      emailAddress: new FormControl(''),
    })
  }
  getcontact(id :any):any
  {
     this.contactService.getContact(id).subscribe(res => {
      // console.log(res,'rrrr');
      this.editContact.patchValue(res);
    
     });
  }
  onSubmit(temp: any) {
    // navigate to contacts page to show all contacts

    //console.log(this.editContact.value)
    this.myRouter.navigate(['allcontacts']);

    this.contactService.updateContact(this.contactId,this.editContact.value).subscribe({
      next: (result) => {
        console.log(result)
        this.toastr.success('Updated successfully!')
      },
      error: (error) => {
        this.toastr.error('Something went wrong!')
      },
    })
  }
 
  ngOnInit(): void {
    // this.contact gets value from routing and allows to edit value.
    this.Route.params.subscribe((param)=>{this.contactId=param['id'] });
if(this.contactId)
    {
      this.getcontact(this.contactId);
    }
  console.log(this.contactId); 
}

}
