import { Component, OnInit } from '@angular/core'
import { Email } from '../Models/Email'
import { EmailService } from '../Service/Email.Service'

@Component({
  selector: 'app-sentitems',
  templateUrl: './sentitems.component.html',
  styleUrls: ['./sentitems.component.css'],
})
export class SentitemsComponent implements OnInit {
  SentDetails?: Email[]
  constructor(private emailService: EmailService) {}

  ngOnInit(): void {
    this.emailService.readAll().subscribe((resolve) => {
      this.SentDetails = resolve
    })
  }

  test(id: number | undefined): void {
    this.emailService.readEmail(id).subscribe((resolve) => {
      // navigates to new compoenent to show sent email
    })
  }
}
