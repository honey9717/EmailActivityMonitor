import { HttpClient, HttpParams } from '@angular/common/http'
import { Injectable } from '@angular/core'
import { Observable } from 'rxjs'
import { Contacts } from '../Models/Contact'


@Injectable({
  providedIn: 'root',
})
export class ContactService {
  contact: any = 'http://localhost:5276/api/Contact/ContactAdd'
  contactupd: any = 'http://localhost:5276/api/Contact/ContactUpdate'
  clist: any = 'http://localhost:5276/api/Contact/listAll'
  delete: any = 'http://localhost:5276/api/Contact/deletecontact/'
  getct: any = 'http://localhost:5276/api/Contact'

  constructor(private httpclient: HttpClient) {}

  newContact(contact: Contacts): Observable<Contacts> {
    return this.httpclient.post<Contacts>(this.contact, contact)
  }
  updateContact(id: number | undefined,contact:Contacts): Observable<Contacts> {
    return this.httpclient.put<Contacts>(`${this.contactupd}/${id}`,contact)
  }
  listAllContacts(page:any, pageSize:any): Observable<Contacts[]> {
    return this.httpclient.get<Contacts[]>(this.clist)
  }
  getContact(id: number): Observable<any> {
    return this.httpclient.get(`${this.getct}/${id}`);
  }
  
  deleteContact(id: number | undefined): Observable<Contacts> {
    return this.httpclient.delete<Contacts>(this.delete + id)
  }
 
}
