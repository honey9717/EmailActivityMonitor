import { HttpClient } from '@angular/common/http'
import { Injectable } from '@angular/core'
import { Observable } from 'rxjs'
import { Email } from '../Models/Email'

@Injectable({
  providedIn: 'root',
})
export class EmailService {
  email: any = 'http://localhost:5276/api/Email'
  delete: any = 'http://localhost:5276/api/Email/'

  selectSendNewMailId:string='';
  constructor(private httpclient: HttpClient) {}

  readAll(): Observable<Email[]> {
    return this.httpclient.get<Email[]>(this.email)
  }

  readEmail(id: number | undefined): Observable<Email> {
    return this.httpclient.get<Email>(this.email + id)
  }

  sendEmail(email: Email): Observable<Email> {
    console.log(email)
    console.log(typeof email)
    return this.httpclient.post<Email>(this.email, email)
  }

  // deleteEmail(id: number | undefined): Observable<string> {
  //   return this.httpclient.delete<string>(this.delete + id);
  // }

  uploadAttachment(formData: any): Observable<any> {
    return this.httpclient.post('http://localhost:5276/api/Email/uploadAttachment',
      formData,
      {
        reportProgress: true,
        observe: 'events',
        responseType:'text'
      });
  }
}
