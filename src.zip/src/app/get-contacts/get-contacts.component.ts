import { Component, OnInit } from '@angular/core'
import { Contacts } from '../Models/Contact'
import { ContactService } from '../Service/Contact,Service'
import { ToastrService } from 'ngx-toastr'
import { EmailService } from '../Service/Email.Service'


@Component({
  selector: 'app-get-contacts',
  templateUrl: './get-contacts.component.html',
  styleUrls: ['./get-contacts.component.css'],
})
export class GetContactsComponent implements OnInit {
  myContacts?: Contacts[]
  pageSize :number=4;
  currentPage:number=1;
  totalPages: number = 0;

  constructor(
    private contactService: ContactService,
    private toastr: ToastrService,
    private emailService: EmailService
  ) {}

  ngOnInit(): void {
    this.getContacts();
  }

getContacts(): void {
  this.contactService
    .listAllContacts(this.currentPage, this.pageSize)
    .subscribe((contacts) => {
      this.myContacts = contacts;
      this.totalPages = Math.ceil(contacts.length / this.pageSize);
    });
}


  changePage(page: number): void {
    if (page > 0 && page <= this.totalPages) {
      this.currentPage = page;
      this.getContacts();
    }
  }

  getPageNumbers(): number[] {
    return Array.from({ length: this.totalPages }, (_, index) => index + 1);
  }

  deleteContact(contactId: number | undefined): void {
    if (confirm('Are you sure to delete the contact?'))  
    this.contactService.deleteContact(contactId).subscribe(() => {
      this.toastr.success('Contact deleted successfully!');
    }, (error) => {
      this.toastr.error('Failed to delete contact');
    });
  }
  setNewEmailIdForCompose(email:any){
this.emailService.selectSendNewMailId = email;
 }


}
