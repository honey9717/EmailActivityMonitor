import { NgModule } from '@angular/core'
import { BrowserModule } from '@angular/platform-browser'

import { AppComponent } from './app.component'
import { AddNewContactComponent } from './add-new-contact/add-new-contact.component'
import { ReactiveFormsModule } from '@angular/forms'
import { HttpClientModule } from '@angular/common/http'
import { ContactService } from './Service/Contact,Service'
import { RouterModule, Routes } from '@angular/router'
import { ComposeComponent } from './compose/compose.component'
import { EmailService } from './Service/Email.Service'
import { EditContactComponent } from './edit-contact/edit-contact.component'
import { GetContactsComponent } from './get-contacts/get-contacts.component'
import { SentitemsComponent } from './sentitems/sentitems.component'
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'
import { ToastrModule } from 'ngx-toastr'
import { NgxPaginationModule } from 'ngx-pagination'

const rootRoutes: Routes = [
  { path: '', redirectTo: 'sent', pathMatch: 'full' },
  { path: 'addContact', component: AddNewContactComponent },
  { path: 'compose', component: ComposeComponent },
  { path: 'editContact/:id', component: EditContactComponent },
  { path: 'allcontacts', component: GetContactsComponent },
  { path: 'sent', component: SentitemsComponent },
]

const childRoutes: Routes = [
  { path: 'allcontacts/editContact/:id', component: EditContactComponent },
  { path: 'allcontacts/compose', component: ComposeComponent },
  { path: 'compose/sent', component: SentitemsComponent },
]

@NgModule({
  declarations: [
    AppComponent,
    AddNewContactComponent,
    ComposeComponent,
    EditContactComponent,
    GetContactsComponent,
    SentitemsComponent,
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
    RouterModule.forRoot(rootRoutes),
    RouterModule.forChild(childRoutes),
    NgxPaginationModule
  ],
  providers: [ContactService, EmailService],
  bootstrap: [AppComponent],
})
export class AppModule {}
