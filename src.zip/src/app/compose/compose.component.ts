import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Email } from '../Models/Email';
import { EmailService } from '../Service/Email.Service';
import { HttpEventType } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-compose',
  templateUrl: './compose.component.html',
  styleUrls: ['./compose.component.css'],
})
export class ComposeComponent implements OnInit {
  Compose: FormGroup;
  EmailMessage: Email = new Email();
  fileName?: string;
  progress?: number;
  message?: string;
  
  @Output() public onUploadFinished = new EventEmitter();

  constructor(
    private emailService: EmailService,
    private toastr: ToastrService,
    private router: Router,
   
  ) {
    this.Compose = new FormGroup({
      body: new FormControl(''),
      to: new FormControl('', [Validators.required]),
      cc: new FormControl(''),
      sendAt: new FormControl(''),
      bcc: new FormControl(''),
      subject: new FormControl(''),
      createdAt: new FormControl(''),
      attachmentFileName: new FormControl(''),
      file: new FormControl(''),
    });
  }

  ngOnInit(): void 
  {
    if(this.emailService.selectSendNewMailId!=''){
 this.Compose.get('to')?.setValue(this.emailService.selectSendNewMailId);
 this.Compose.controls['to'].disable();
 }
  
  }

  uploadFile(files: any): void {
    if (files.length === 0) {
      return;
    }
    const formData = new FormData();
    this.fileName = files[0].name;
    const fileToUpload = files[0];
    this.EmailMessage.file = fileToUpload;
    formData.append('file', fileToUpload, fileToUpload.name);

    this.emailService.uploadAttachment(formData).subscribe({
      next: (event) => {
        if (event.type === HttpEventType.UploadProgress) {
          this.progress = Math.round((100 * event.loaded) / event.total);
        } else if (event.type === HttpEventType.Response) {
          this.message = 'Upload success.';
          this.onUploadFinished.emit(event.body);
        }
      },
    });
  }

  scheduleSend(): void {}

  onSubmit() {
    this.EmailMessage.to = this.Compose.get('to')?.value.split(';');
    this.EmailMessage.cc = this.Compose.get('cc')?.value.split(';');
    this.EmailMessage.bcc = this.Compose.get('bcc')?.value.split(';');
    this.EmailMessage.subject = this.Compose.get('subject')?.value;
    this.EmailMessage.body = this.Compose.get('body')?.value;
    this.EmailMessage.attachmentFileName = this.fileName;
    this.EmailMessage.sendAt = new Date();
    this.EmailMessage.createdAt = new Date();
    this.EmailMessage.emailStatus = 'Pending';

    this.router.navigate(['sent']);
    this.emailService.sendEmail(this.EmailMessage).subscribe(
      (result) => {
        console.log(result);
        this.toastr.success('Email sent successfully!');
      },
      (error) => {
        this.toastr.error('Something went wrong!');
      }
    );
  }

  get to() {
    return this.Compose.get('to');
  }
}

