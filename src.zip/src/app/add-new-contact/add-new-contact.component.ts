import { Component, OnInit } from '@angular/core'
import { FormControl, FormGroup, Validators } from '@angular/forms'
import { Contacts } from '../Models/Contact'
import { ContactService } from '../Service/Contact,Service'
import { ToastrService } from 'ngx-toastr'
import { Router } from '@angular/router'

@Component({
  selector: 'app-add-new-contact',
  templateUrl: './add-new-contact.component.html',
  styleUrls: ['./add-new-contact.component.css'],
})
export class AddNewContactComponent implements OnInit {
  addContact: FormGroup
  MyContact: Contacts = new Contacts()

  constructor(
    private contactService: ContactService,
    private toastr: ToastrService,
    private myRouter:Router
  ) {
    this.addContact = new FormGroup({
      address: new FormControl(''),
      lastName: new FormControl('', [
        Validators.required,
        Validators.minLength(3),
      ]),
      firstName: new FormControl('', [
        Validators.required,
        Validators.minLength(3),
      ]),
      phoneNumber: new FormControl('', [
        Validators.required,
        Validators.pattern(/^\d{10}$/),
      ]),
      emailAddress: new FormControl('', [
        Validators.email,
        Validators.required,
      ]),
    })
  }

  onSubmit(temp: any) {
    this.myRouter.navigate(['allcontacts']);
    this.contactService.newContact(this.addContact.value).subscribe(
      (result) => {
        console.log(result)
        this.toastr.success('Contact added successfully!')
      },
      (error) => {
        this.toastr.error('Something went wrong!')
      },
    )
  }
  ngOnInit(): void {}

  get firstName() {
    return this.addContact.get('firstName')
  }
  get lastName() {
    return this.addContact.get('lastName')
  }
  get emailAddress() {
    return this.addContact.get('emailAddress')
  }
  get address() {
    return this.addContact.get('address')
  }
  get phoneNumber() {
    return this.addContact.get('phoneNumber')
  }
}
