using EmailActivityMonitor.Database;
using EmailActivityMonitor.Functionality.Services;
using EmailActivityMonitor.ViewModel.DTO;
using EmailActivityMonitor.ViewModel.DTOValidation;
using FluentValidation;
using Microsoft.EntityFrameworkCore;
using EmailActivityMonitor.DynamicMigration;
using SendGrid.Extensions.DependencyInjection;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddDbContext<EmailDbContext>(d => d.UseNpgsql(builder.Configuration.GetConnectionString("dbConnection")));
builder.Services.AddTransient<IContactService,ContactService>();
builder.Services.AddTransient<IEmailService,EmailService>();
builder.Services.AddScoped<IValidator<ContactDTO>,ContactDTOValidation >();     // doing IOC of Ivalidator 
builder.Services.AddValidatorsFromAssemblyContaining<ContactDTOValidation>(); 
builder.Services.AddControllersWithViews().AddNewtonsoftJson(options => options.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore); 
builder.Services.AddCors();
builder.Services.Configure<EmailService>
    (options => builder.Configuration.GetSection("EmailSettings").Bind(options));

builder.Services.AddSendGrid(options =>
{
    options.ApiKey = builder.Configuration
    .GetSection("EmailSettings").GetValue<string>("SendGridKey");
});
var app = builder.Build();
app.UseCors(x => x
.AllowAnyMethod()
.AllowAnyHeader()
 .SetIsOriginAllowed(origin => true)
.AllowCredentials());
// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
app.UseMigration();

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
