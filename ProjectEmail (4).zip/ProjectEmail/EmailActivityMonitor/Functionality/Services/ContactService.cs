using System;
using EmailActivityMonitor.Database;
using EmailActivityMonitor.Models.Entity;
using EmailActivityMonitor.ViewModel.DTO;
using Microsoft.EntityFrameworkCore;

namespace EmailActivityMonitor.Functionality.Services
{
    public class ContactService : IContactService
    {
        private readonly EmailDbContext _dbContext;

        public ContactService(EmailDbContext dbContext)      //Applying DI
        {
            _dbContext = dbContext;
        }

        public async Task<ContactDTO> GetContact(int id)           //From this function we are getting the single contact through id
        {
            var contact = await _dbContext.contacts.FindAsync(id);
            return MapToDTO(contact);
        }

        public async Task<List<ContactDTO>> GetAllContact()        //this function returns contactList 
        {
            var contacts = await _dbContext.contacts.ToListAsync();
            return contacts.Select(MapToDTO).ToList();
        }

        public async Task UpdateContact(ContactDTO contact,int id)         //By this we can update the contacts
        {
            var existingContact =
                await _dbContext.contacts.FindAsync(id);
            if (existingContact == null)
            {
                throw new ArgumentException($"Contact with ID {
                        contact.ContactId} not found");
            }
            existingContact.FirstName = contact.FirstName;
            existingContact.EmailAddress = contact.EmailAddress;
            existingContact.PhoneNumber = contact.PhoneNumber;
            existingContact.LastName = contact.LastName;
            existingContact.Address = contact.Address;
            await _dbContext.SaveChangesAsync();
        }

        public async Task DeleteContact(int id)        //By this we can delete the contact through id
        {
            var contact = await _dbContext.contacts.FindAsync(id);
            if (contact == null)
            {
                throw new ArgumentException($"Contact with ID {id} not found");
            }
            _dbContext.contacts.Remove (contact);
            await _dbContext.SaveChangesAsync();
            
        }

        public ContactDTO MapToDTO(Contact contact)      //ToDTO and MapToDto are methods or patterns used to convert a data entity 
                                                       //(e.g., Contact) to a data transfer object (DTO) (e.g., ConatctDTO), and vice versa.
        {
            return new ContactDTO {
                FirstName = contact.FirstName,
                LastName = contact.LastName,
                EmailAddress = contact.EmailAddress,
                PhoneNumber = contact.PhoneNumber,
                Address = contact.Address,
                ContactId = contact.ContactId
            };
        }

        public Contact MapToEntity(ContactDTO contactDTO, Contact contact = null)
        {
            if (contact == null)
            {
                contact = new Contact();
            }

            contact.FirstName = contactDTO.FirstName;
            contact.EmailAddress = contactDTO.EmailAddress;
            contact.PhoneNumber = contactDTO.PhoneNumber;
            return contact;
        }

        int IContactService.AddContact(ContactDTO contact)        //By this function we can add contact
        {
            int Id = 0;
            if(_dbContext.contacts.Any(U=>U.EmailAddress==contact.EmailAddress))
            {
            throw new ArgumentException($"Email {contact.EmailAddress} already exists");
           
            }
             if(_dbContext.contacts.Any(t=>t.PhoneNumber==contact.PhoneNumber))
            {
            throw new ArgumentException($"PhoneNumber {contact.PhoneNumber} already exists");
            }
   
            Contact contactobj = new Contact();
            contactobj.FirstName = contact.FirstName;
            contactobj.LastName = contact.LastName;
            contactobj.EmailAddress = contact.EmailAddress;
            contactobj.PhoneNumber = contact.PhoneNumber;
            contactobj.Address = contact.Address;

            Id = contactobj.ContactId;
            _dbContext.contacts.Add (contactobj);

            return _dbContext.SaveChanges();
        }
    }
}

