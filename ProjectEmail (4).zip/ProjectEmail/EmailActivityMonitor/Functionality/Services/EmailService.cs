using System;
using EmailActivityMonitor.Database;
using EmailActivityMonitor.Models.Entity;
using EmailActivityMonitor.ViewModel.DTO;
using Microsoft.EntityFrameworkCore;
using SendGrid;
using SendGrid.Helpers.Mail;

namespace EmailActivityMonitor.Functionality.Services
{
    public class EmailService : IEmailService
    {
        private readonly EmailDbContext _dbContext;

        private readonly IConfiguration _configuration;

        public EmailService(
            EmailDbContext dbContext,
            IConfiguration configuration
        )
        {
            _configuration = configuration;
            _dbContext = dbContext;
        }

        public async Task<EmailDTO> SendMailAsync(EmailDTO email)
        {
            // Using SendGridAPI to send this email to the recipients (every email id in to, cc, bcc)
            var client =
                new SendGridClient("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");
            var From =
                new EmailAddress("sidhant.tyagi@taazaa.com", "HoneySidhant");
            foreach (var toEmail in email.To)
            {
                var to = new EmailAddress(toEmail);
                var msg =
                    MailHelper
                        .CreateSingleEmail(From,
                        to,
                        email.Subject,
                        email.Body,
                        "");
              
               
  if (email.AttachmentFileName != null)
    {
        var attachedFilePath = Path.Combine(Directory.GetCurrentDirectory(), "Recources", "Attachments", email.AttachmentFileName);
        var bytes = await File.ReadAllBytesAsync(attachedFilePath);
        
        var file = Convert.ToBase64String(bytes);
        var attachment = new SendGrid.Helpers.Mail.Attachment
        {
            Content = file,
            Filename = email.AttachmentFileName
        };
        msg.AddAttachment(attachment);
    }


 if(email.CC.Length==1 && email.CC[0]==""){}
 else
{
    List<EmailAddress> ToCcList = new List<EmailAddress>();
    foreach(var ccEmail in email.CC){
    ToCcList.Add(new EmailAddress(ccEmail));
    }
    msg.AddCcs(ToCcList);
 }

  
     if(email.BCC.Length==1 && email.BCC[0]==""){}
     else{
    List<EmailAddress> ToBCCList = new List<EmailAddress>();
    foreach(var bccEmail in email.BCC){
    ToBCCList.Add(new EmailAddress(bccEmail));
    }
    msg.AddBccs(ToBCCList);
     
    }
     var response = await client.SendEmailAsync(msg);
            }

            // validate email input here
          
            var entity =
                new Email {
                    To = string.Join(',', email.To),
                    CC = string.Join(',', email.CC),
                    BCC = string.Join(',', email.BCC),
                    Subject = email.Subject,
                    Body = email.Body,
                    AttachmentFileName = email.AttachmentFileName,
                    CreatedAt = DateTime.UtcNow,
                    SendAt = email.SendAt,
                    EmailStatus = "Pending",
                    Id = email.Id
                };

            _dbContext.email.Add (entity);
            await _dbContext.SaveChangesAsync();
            return ToDTO(entity);
        }


        public async Task<EmailDTO> ReadMailAsync(int id)
        {
            var entity = await _dbContext.email.FindAsync(id);
            return ToDTO(entity);
        }

        public async Task<IEnumerable<EmailDTO>> AllMailAsync()
        {
            var entities = await _dbContext.email.ToListAsync();
            return entities.Select(ToDTO);
        }

        public async Task<string> DeleteMailAsync(int id)
        {
            var entity = await _dbContext.email.FindAsync(id);
            if (entity == null) return "Email not found";
            _dbContext.email.Remove (entity);
            await _dbContext.SaveChangesAsync();
            return "Email deleted successfully";
        }

        public async Task<List<EmailDTO>> GetMailsByEmailAddress(int id)
        {
            var entities =
                await _dbContext.email.Where(e => e.Id == id).ToListAsync();
            return entities.Select(ToDTO).ToList();
        }

        public EmailDTO
        ToDTO(
            Email entity
        )//(e.g., EmailEntity) to a data transfer object (DTO) (e.g., EmailDTO), and vice versa. //ToDTO and MapToDto are methods or patterns used to convert a data entity

        {
            if (entity == null) return null;
            return new EmailDTO {
                To =
                    entity
                        .To?
                        .Split(',', StringSplitOptions.RemoveEmptyEntries),
                CC =
                    entity
                        .CC?
                        .Split(',', StringSplitOptions.RemoveEmptyEntries),
                BCC =
                    entity
                        .BCC?
                        .Split(',', StringSplitOptions.RemoveEmptyEntries),
                Subject = entity.Subject,
                Body = entity.Body,
                AttachmentFileName = entity.AttachmentFileName,
                CreatedAt = entity.CreatedAt,
                SendAt = entity.SendAt,
                EmailStatus = entity.EmailStatus,
                Id = entity.Id
            };
        }
    }
}
