using System;
using EmailActivityMonitor.ViewModel.DTO;

namespace EmailActivityMonitor.Functionality.Services
{
    public interface IContactService
    {
    Task<ContactDTO> GetContact(int id);            
     Task<List<ContactDTO>> GetAllContact();        
     public int AddContact(ContactDTO contact);    
    Task UpdateContact(ContactDTO contact,int id);      
    Task DeleteContact(int id);
    }
}