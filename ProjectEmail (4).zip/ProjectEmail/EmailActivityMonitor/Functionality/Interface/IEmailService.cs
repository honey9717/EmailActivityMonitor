using System;
using EmailActivityMonitor.ViewModel.DTO;

namespace EmailActivityMonitor.Functionality.Services
{
    public interface IEmailService
    {
        Task<EmailDTO> SendMailAsync(EmailDTO Mail);
        Task<EmailDTO> ReadMailAsync(int Id);
        Task<IEnumerable<EmailDTO>> AllMailAsync();
        Task<string> DeleteMailAsync(int Id);
        Task<List<EmailDTO>> GetMailsByEmailAddress(int Id);
    }
}
