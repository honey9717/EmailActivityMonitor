using System;
using EmailActivityMonitor.Models.Entity;
using EmailActivityMonitor.Models.EntityMapper;
using Microsoft.EntityFrameworkCore;

namespace EmailActivityMonitor.Database
{
    public class EmailDbContext : DbContext
    {
        public EmailDbContext(DbContextOptions dbContextOptions) :
            base(dbContextOptions)
        {
            AppContext.SetSwitch("Npgsql.EnableLegacyTimestampBehavior", true);
        }

        public DbSet<Contact> contacts { get; set; }

        public DbSet<Email> email { get; set; }

        protected override void OnModelCreating(ModelBuilder modelbuilder)
        {
            // Now apply association between Contact and ContactMapper , Email and EmailMapper  
            new ContactMapper(modelbuilder.Entity<Contact>());
            new EmailMapper(modelbuilder.Entity<Email>());
            
            // Seeding data for "system added contact"
            modelbuilder
                .Entity<Contact>()
                .HasData(new Contact {
                    ContactId = 101,
                    FirstName = "Honey",
                    LastName = "Tomar",
                    EmailAddress = "hunnytomar09@gmail.com",
                    PhoneNumber = 9717094930,
                    Address = "EastDelhi"
                });

             // Seeding data for "system added email"    
            modelbuilder
                .Entity<Email>()
                .HasData(new Email {
                    Id = 110,
                    Subject = "Leave Application",
                    Body = "Hiii Everyone",
                    To = "sidhant@gmail.com",
                    CC = "shivam@gmail.com",
                    BCC = "prabhat@gmail.com",
                    AttachmentFileName = "DatabseFolder",
                    CreatedAt = new DateTime(2015, 5, 15, 13, 45, 0),
                    SendAt = new DateTime(2016, 6, 16, 14, 46, 1),
                    EmailStatus = "Sent"
                });
        }
    }
}
