using System;

namespace EmailActivityMonitor.ViewModel.DTO
{
    public class ContactDTO
    {
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string EmailAddress { get; set; }

        public long PhoneNumber { get; set; }

        public string Address { get; set; }

        public int ContactId { get; set; }
    }
}
