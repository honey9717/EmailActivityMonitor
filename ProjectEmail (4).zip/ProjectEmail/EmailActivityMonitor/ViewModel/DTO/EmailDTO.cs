using System;

namespace EmailActivityMonitor.ViewModel.DTO
{
    public class EmailDTO
    {
        public int Id { get; set; }
        public string[] To { get; set; }
        public string[] CC { get; set; }
        public string[] BCC { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        public string AttachmentFileName { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime SendAt { get; set; }
        public string EmailStatus { get; set; }
    }
}
