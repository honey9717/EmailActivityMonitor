using System;
using EmailActivityMonitor.ViewModel.DTO;
using FluentValidation;

namespace EmailActivityMonitor.ViewModel.DTOValidation
{
    public class ContactDTOValidation : AbstractValidator<ContactDTO>
    {
        public ContactDTOValidation()
        {
            RuleFor(c => c.EmailAddress).EmailAddress();
            RuleFor(c => c.PhoneNumber.ToString()).Length(10, 10);
        }
    }
}
