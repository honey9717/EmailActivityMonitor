using System;
using EmailActivityMonitor.ViewModel.DTO;
using FluentValidation;

namespace EmailActivityMonitor.ViewModel.DTOValidation
{
    public class EmailDTOValidation : AbstractValidator<EmailDTO>
    {
        public EmailDTOValidation()
        {
            RuleFor(e => e.To.Length).GreaterThanOrEqualTo(1); // must have at least one recipient
            RuleFor(e => e.CreatedAt).NotNull();
            RuleFor(e => e.SendAt).NotNull();
        }
    }
}
