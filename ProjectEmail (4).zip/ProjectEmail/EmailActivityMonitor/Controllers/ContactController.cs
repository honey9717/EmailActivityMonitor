using System;
using EmailActivityMonitor.Functionality.Services;
using EmailActivityMonitor.ViewModel.DTO;
using FluentValidation;
using FluentValidation.Results;
using Microsoft.AspNetCore.Mvc;

namespace EmailActivityMonitor.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ContactController : ControllerBase
    {
        private readonly IContactService _contactService;

        private IValidator<ContactDTO> validator;

        public ContactController(                    //Applying DI
            IContactService contactService,
            IValidator<ContactDTO> _validator
        )
        {
            this._contactService = contactService;
            this.validator = _validator;
        }
  
        [HttpGet]    
        [Route("listAll")]             //Route Attribute
        public async Task<ActionResult<List<ContactDTO>>> GetAllContact()
        {
            var contacts = await _contactService.GetAllContact();
            return Ok(contacts);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<ContactDTO>> GetContact(int id)
        {
            var contact = await _contactService.GetContact(id);
            if (contact == null)
            {
                return NotFound();
            }
            return Ok(contact);
        }

        [HttpPost("ContactAdd")]
        public IActionResult AddContact([FromBody] ContactDTO contact)
        {
            ValidationResult result = validator.Validate(contact);
            if (result.IsValid)
            {
                return Ok(_contactService.AddContact(contact));
            }
            else
            {
                return BadRequest(result.Errors);
            }
        }

        [HttpPut]
        [Route("ContactUpdate/{id}")]
        public async Task<ActionResult<ContactDTO>>
        UpdateContact([FromBody] ContactDTO contact,[FromRoute] int id)
        {
            try
            {
                await _contactService.UpdateContact(contact,id);
                return Ok(contact);
            }
            catch (Exception)
            {
                return BadRequest($"This contact was not found! Try creating new contact for this person!");
            }
        }

        [HttpDelete]
        [Route("Deletecontact/{id}")]
        public async Task<IActionResult> DeleteContact(int id)
        {
            await _contactService.DeleteContact(id);
            return NoContent();
        }
    }
}
