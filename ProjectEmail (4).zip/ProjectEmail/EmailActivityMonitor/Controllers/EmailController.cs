using System;
using EmailActivityMonitor.Functionality.Services;
using EmailActivityMonitor.ViewModel.DTO;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http.Headers;

namespace EmailActivityMonitor.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EmailController : ControllerBase
    {
        IEmailService _emailService;

        public EmailController(IEmailService emailService)    //Applying DI
        {
            this._emailService = emailService;
        }

        [HttpPost]
        public async Task<ActionResult<EmailDTO>> SendEmailAsync(EmailDTO email)
        {
            var result = await _emailService.SendMailAsync(email);
            return Ok(result);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<EmailDTO>> ReadEmailAsync(int id)
        {
            var result = await _emailService.ReadMailAsync(id);
            return Ok(result);
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<EmailDTO>>>
        GetAllEmailsAsync()
        {
            var result = await _emailService.AllMailAsync();
            return Ok(result);
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult<string>> DeleteEmailAsync(int id)
        {
            var result = await _emailService.DeleteMailAsync(id);
            return Ok(result);
        }

        [HttpGet("by-email-address/{id}")]
        public async Task<ActionResult<List<EmailDTO>>>
        GetEmailsByEmailAddress(int id)
        {
            var result = await _emailService.GetMailsByEmailAddress(id);
            return Ok(result);
        }
         [HttpPost, DisableRequestSizeLimit]
        [Route("uploadAttachment")]
        public async Task<IActionResult> UploadAttachmentAsync()
        {
            try
            {
                var FormCollection = await Request.ReadFormAsync();
                var File = FormCollection.Files.First();
                var FolderName = Path.Combine("Recources", "Attachments");
                var PathToSave = Path.Combine(Directory.GetCurrentDirectory(), FolderName);
                Directory.CreateDirectory(PathToSave);
                if (File.Length > 0)
                {
                    var FileName = ContentDispositionHeaderValue.Parse(File.ContentDisposition).FileName.Trim('"');
                    var FullPath = Path.Combine(PathToSave, FileName);
                    using (var Stream = new FileStream(FullPath, FileMode.Create))
                    {
                        File.CopyTo(Stream);
                    }
                }
                return StatusCode(200, "Attachment File Uploaded");
            }
            catch (Exception exception)
            {
                return StatusCode(500, $"Internal Server Error: {exception}");
            }
        }
    }
}
