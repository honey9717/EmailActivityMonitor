using System;

namespace EmailActivityMonitor.ExtensionMethod
{
    public static class EmailSettings
    {
        public static string[]
        GetSenderInfo(
            this IConfiguration Configuration,
            string ConfigurationSection,
            string EmailAddress,
            string SenderName
        )
        {
            return new string[] {
                Configuration
                    .GetSection($"{ConfigurationSection}:{EmailAddress}")
                    .Value,
                Configuration
                    .GetSection($"{ConfigurationSection}:{SenderName}")
                    .Value
            };
        }
    }
}
