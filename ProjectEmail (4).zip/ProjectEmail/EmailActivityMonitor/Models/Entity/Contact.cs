using System;

namespace EmailActivityMonitor.Models.Entity
{
    public class Contact
    {
        public int ContactId { get; set; }       //primary key

        public string? FirstName { get; set; }

        public string? LastName { get; set; }

        public string? EmailAddress { get; set; }

        public long PhoneNumber { get; set; }

        public string? Address { get; set; }

        public virtual ICollection<Email>? email { get; set; }               //Navigation 
    }
}
