using System;

namespace EmailActivityMonitor.Models.Entity
{
    public class EmailRecipient
    {
        public int RecipientId { get; set; }          

        public int EmailId { get; set; }

        public int ContactId { get; set; }

        public string? RecipientType { get; set; }
    }
}
