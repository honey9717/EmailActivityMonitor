using System;

namespace EmailActivityMonitor.Models.Entity
{
    public class Email
    {
        public int Id { get; set; }            //primary key

        public string? To { get; set; }

        public string? CC { get; set; }

        public string? BCC { get; set; }

        public string? Subject { get; set; }

        public string? Body { get; set; }

        public string? AttachmentFileName { get; set; }

        public DateTime CreatedAt { get; set; }

        public DateTime SendAt { get; set; }

        public string? EmailStatus { get; set; }

        public virtual ICollection<Contact>? contacts { get; set; }          //Navigation
    }
}
