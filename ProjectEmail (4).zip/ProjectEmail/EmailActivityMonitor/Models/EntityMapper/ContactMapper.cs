using System;
using EmailActivityMonitor.Models.Entity;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace EmailActivityMonitor.Models.EntityMapper
{
    public class ContactMapper
    {
        //Here we apply the fluent api
        public ContactMapper(EntityTypeBuilder<Contact> entityTypeBuilder)
        {
            entityTypeBuilder.HasKey(i => i.ContactId);          //Primary Key
            entityTypeBuilder.Property(e => e.FirstName).IsRequired();
            entityTypeBuilder.Property(e => e.LastName).IsRequired();                                //NotNull constraints
            entityTypeBuilder.Property(e => e.EmailAddress).IsRequired();
            entityTypeBuilder.Property(e => e.PhoneNumber).IsRequired();
        }
    }
}
