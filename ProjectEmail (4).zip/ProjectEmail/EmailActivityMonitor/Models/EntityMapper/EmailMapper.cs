using System;
using EmailActivityMonitor.Models.Entity;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace EmailActivityMonitor.Models.EntityMapper
{
    public class EmailMapper
    {
        //Here we apply the fluent api
        public EmailMapper(EntityTypeBuilder<Email> entityTypeBuilder)
        {
            entityTypeBuilder.HasKey(e => e.Id);           //Primary Key
            entityTypeBuilder.Property(e => e.To).IsRequired();       //NotNull Constraints

            entityTypeBuilder
                .HasMany(t => t.contacts)
                .WithMany(u => u.email)
                .UsingEntity<EmailRecipient>();
        }
    }
}
