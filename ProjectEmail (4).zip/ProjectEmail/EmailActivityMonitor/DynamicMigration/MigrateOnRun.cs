using System;
using EmailActivityMonitor.Database;
using Microsoft.EntityFrameworkCore;


namespace EmailActivityMonitor.DynamicMigration
{
    public static class MigrateOnRun
    {
        public static void UseMigration(this IApplicationBuilder app)
        {
            using (var createdScope = app.ApplicationServices.CreateScope())
            {
                createdScope
                    .ServiceProvider
                    .GetService<EmailDbContext>()
                    .Database
                    .Migrate();
            }
        }
    }
}
