﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace EmailActivityMonitor.Migrations
{
    /// <inheritdoc />
    public partial class emaildb1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "contacts",
                columns: table => new
                {
                    ContactId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    FirstName = table.Column<string>(type: "text", nullable: false),
                    LastName = table.Column<string>(type: "text", nullable: false),
                    EmailAddress = table.Column<string>(type: "text", nullable: false),
                    PhoneNumber = table.Column<long>(type: "bigint", nullable: false),
                    Address = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_contacts", x => x.ContactId);
                });

            migrationBuilder.CreateTable(
                name: "email",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    EmailAddress = table.Column<string>(type: "text", nullable: false),
                    To = table.Column<string>(type: "text", nullable: false),
                    CC = table.Column<string>(type: "text", nullable: true),
                    BCC = table.Column<string>(type: "text", nullable: true),
                    Subject = table.Column<string>(type: "text", nullable: true),
                    Body = table.Column<string>(type: "text", nullable: true),
                    AttachmentFileName = table.Column<string>(type: "text", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    SendAt = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    EmailStatus = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_email", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "EmailRecipient",
                columns: table => new
                {
                    EmailId = table.Column<int>(type: "integer", nullable: false),
                    ContactId = table.Column<int>(type: "integer", nullable: false),
                    RecipientId = table.Column<int>(type: "integer", nullable: false),
                    RecipientType = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EmailRecipient", x => new { x.ContactId, x.EmailId });
                    table.ForeignKey(
                        name: "FK_EmailRecipient_contacts_ContactId",
                        column: x => x.ContactId,
                        principalTable: "contacts",
                        principalColumn: "ContactId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_EmailRecipient_email_EmailId",
                        column: x => x.EmailId,
                        principalTable: "email",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "contacts",
                columns: new[] { "ContactId", "Address", "EmailAddress", "FirstName", "LastName", "PhoneNumber" },
                values: new object[] { 101, "EastDelhi", "hunnytomar09@gmail.com", "Honey", "Tomar", 9717094930L });

            migrationBuilder.InsertData(
                table: "email",
                columns: new[] { "Id", "AttachmentFileName", "BCC", "Body", "CC", "CreatedAt", "EmailAddress", "EmailStatus", "SendAt", "Subject", "To" },
                values: new object[] { 110, "DatabseFolder", "prabhat@gmail.com", "Hiii Everyone", "shivam@gmail.com", new DateTime(2015, 5, 15, 13, 45, 0, 0, DateTimeKind.Unspecified), "hunnytomar09@gmail.com", "Sent", new DateTime(2016, 6, 16, 14, 46, 1, 0, DateTimeKind.Unspecified), "Leave Application", "sidhant@gmail.com" });

            migrationBuilder.CreateIndex(
                name: "IX_EmailRecipient_EmailId",
                table: "EmailRecipient",
                column: "EmailId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "EmailRecipient");

            migrationBuilder.DropTable(
                name: "contacts");

            migrationBuilder.DropTable(
                name: "email");
        }
    }
}
