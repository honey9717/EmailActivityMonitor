﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EmailActivityMonitor.Migrations
{
    /// <inheritdoc />
    public partial class emaildb2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "EmailAddress",
                table: "email");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "EmailAddress",
                table: "email",
                type: "text",
                nullable: false,
                defaultValue: "");

            migrationBuilder.UpdateData(
                table: "email",
                keyColumn: "Id",
                keyValue: 110,
                column: "EmailAddress",
                value: "hunnytomar09@gmail.com");
        }
    }
}
