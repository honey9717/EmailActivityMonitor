---------- -----------------------------Email Activity Monitor with Contact List----------------------------------------------
To set up this project first run  the command 
1. dotnet ef migrations add and pass the name of it   
ex dotnet ef migrations add emaildb1
After that run the command dotnet ef database update 

To start the API run the command----------------------------------------------------------
 dotnet watch run     

From this project 

